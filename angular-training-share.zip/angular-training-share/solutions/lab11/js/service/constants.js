'use strict';

/**
 * Application Constants.
 **/
 app.constant('error', {
 	'SYSTEM_ISSUE_ERROR': 'Sorry, we are having server issues',
 	'NO_ERRORS': '',
 	'DEPRECATED': 'This has been deprecated'
 });

