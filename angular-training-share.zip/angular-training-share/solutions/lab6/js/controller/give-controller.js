'use strict';

/**
 * Home Controller for the home route.
 **/
 app.controller('GiveController', ['$scope', function($scope) {
 	
 	//Setting the page properties
 	$scope.page = {
 		heading: 'Give'
 	};

 }]);