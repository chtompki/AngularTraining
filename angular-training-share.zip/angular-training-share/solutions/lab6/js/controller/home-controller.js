'use strict';

/**
 * Home Controller for the home route.
 **/
 app.controller('HomeController', ['$scope', function($scope) {
 	
 	//Setting the page properties
 	$scope.page = {
 		heading: 'This one\'s on me'
 	};

 }]);