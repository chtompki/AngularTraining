'use strict';

app.directive('diHome', function() {
	return {
		restrict: 'EA',
		replace: true,
		scope: {
			diUrl: '=',
			diLinkText: '='
		},
    	template: '<a href="{{diUrl}}" target="_blank">{{diLinkText}}</a>'
	};
});





