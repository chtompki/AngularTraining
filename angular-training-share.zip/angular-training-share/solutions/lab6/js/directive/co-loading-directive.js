
angular.module('co.common.directives')
.directive('coLoading', ['$rootScope', '$timeout',
    function($rootScope,$timeout) {
  
    return {
    link: function(scope, element, attrs) {
      
      element.addClass('hide');

      $rootScope.$on('$stateChangeStart', function() {
        element.removeClass('hide');
      });

      $rootScope.$on('$stateChangeSuccess', function() {
        
        $timeout(function(){
          element.addClass('hide');
        },1000);
        
      });

    }
  };
}]);
