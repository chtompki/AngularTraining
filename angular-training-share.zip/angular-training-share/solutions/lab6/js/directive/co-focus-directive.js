
angular.module('co.common.directives', []);

angular.module('co.common.directives')
.directive('coFocus',function() {
      return {
      link: function(scope, element, attrs) {
        element[0].focus();
      }
  };
});