'use strict';
/**
 * Controller handling the lemon report listing directives
 **/
//app.controller('lemonReportListingController', function($scope) {
	
	//Set the grossProfit on the parent controller
	//$scope.reportItem.grossProfit = $scope.reportItem.netSale - $scope.reportItem.costOfGoods;

	//Communicte to the child directive the grossProfit
	//this.grossProfit = $scope.reportItem.grossProfit;

//});

/**
 * Directive for each report item
 *	parent directive holding report listing footers
 **/
app.directive('lemonReportListing', function() {

	return {
		//Only want attribute directive
		restrict: 'EA',  
		//Isolate scope
    	scope: {
    		//2 way binding on a report object
    		reportItem: '=',
    		//Referencing a method on the parent scope
    		action: '&',
    		//Local scope binding
    		limit: '='
    	},
    	//Include user-defined HTML
    	transclude: true,
    	//We want to deal with an external template
		templateUrl: '/templates/directive/report-listing.html',
		//Utilizing the lemonReportListingController
		//controller: 'lemonReportListingController',
		//Link function handles selected click
		link: function(scope, instanceElement) {

			//Setting flag on parent controller
			scope.reportItem.profitable = scope.reportItem.grossProfit > 200 ? true : false;

			//Setting the selected item
			scope.showSelected = function() {
				scope.action({selectedReport: scope.reportItem});
			};

			//Setting up binding on a report item to make it selected
			instanceElement.bind('click', function() {
				//Utilizing jqLite DOM crawling
				//	Removing all 'selected' classes
				instanceElement.parent().children().removeClass('selected');
				//Adding a 'selected' class to the clicked report item
				instanceElement.addClass('selected');
			});
		}
	};
});

