'use strict';
/**
 *  Directive to be used across all page headers.
 **/
app.directive('lemonHeading', function() {
	return {
		restrict: 'AE',  
    	scope: true,
		template: '<h2>{{page.heading}}</h2>'
	};
});

app.directive('lemonHeading2', function() {
	return {
		restrict: 'AE',  
    	scope: {
    		pageHeading : '@', 	

    	},
		template: '<h2>{{pageHeading}}</h2>'
	};
});

app.directive('lemonHeading3', function() {
	return {
		restrict: 'AE',  
    	scope: true,
    	transclude: true,
		template: '<h2 ng-transclude></h2>'
	};
});